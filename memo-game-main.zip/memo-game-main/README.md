# 🧠 Memory training game. JavaScript
This is a simple memory training game written in the JavaScript language. In it you need to find all the same pairs of cards in a certain time.

<h2>🕹️ Play:</h2>
https://stnnickk.github.io/memo-game/

<h2>👀 Preview:</h2>
<img src="https://user-images.githubusercontent.com/62311828/191317154-a773b3bd-f4fd-4de6-ae24-ec78f97c7eb1.gif" alt="preview" width="400" height="400" />
